"use client"
import { useEffect, useState } from 'react';
import Image from 'next/image';
import PayButton from '@/components/PayButton';

interface Product {
  id: string;
  image: string;
  title: string;
  price: number;
  description: string;
  metadata?: {
    stock?: number;
    new?: boolean;
    hidden?: boolean;
    category?: string;
  };
}

interface PageProps {
  params: {
    pid: string;
  };
}

export default function Page({ params }: PageProps) {
  const [product, setProduct] = useState<Product | null>(null);
  const pid = params.pid;

  useEffect(() => {
    const fetchProduct = async () => {
      const response = await fetch("/api/product/", { headers: { pid: pid } });
      const data = await response.json();
      setProduct(data);
    };

    fetchProduct();
  }, [pid]);

  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return <div>Loading...</div>;
  }

  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleIncrease = () => {
    if (product.metadata?.stock && quantity >= product.metadata?.stock) {
      return;
    }
    setQuantity(quantity + 1);
  };
  return (
    <>
      <div className="bg-neutral mx-10 p-4 rounded-b-xl">
        <button onClick={() => window.history.back()} className="btn btn-primary hover:btn-secondary">Back</button>
        <section className="container flex-grow mx-auto max-w-[1200px] border-b py-5 lg:grid lg:grid-cols-2 lg:py-10">
          <div className="container mx-auto px-4">
            {product.image && (
              <Image src={product.image} alt={product.title} width={320} height={320} className="object-cover w-[75%] rounded-2xl" />
            )}
            {!product.image && (
              <Image src={"/assets/logo.png"} alt={product.title} width={320} height={320} className="object-cover w-[75%] rounded-2xl" />
            )}
          </div>
          <div className="mx-auto px-5 lg:px-5">
            <h2 className="pt-3 text-5xl font-bold lg:pt-0 text-secondary-content">
              {product.title}
            </h2>
            <p className="mt-4 text-2xl font-bold text-white">
              {product.price}{"€"}
            </p>
            <hr />
            <p className="pt-5 text-sm leading-5 text-gray-100">
              {product.description}
            </p>
            <div className="mt-6">
              <p className="pb-2 text-xs text-gray-100">Quantity</p>
              <div className="flex">
                <button
                  className="flex h-8 w-8 cursor-pointer items-center justify-center border duration-100 hover:bg-base-100 focus:ring-2 focus:ring-gray-500 active:ring-2 active:ring-gray-500 text-white"
                  onClick={handleDecrease}
                >
                  -
                </button>
                <div className="flex h-8 w-8 cursor-text items-center justify-center border-t border-b active:ring-gray-500 text-white">
                  {quantity}
                </div>
                <button
                  className="flex h-8 w-8 cursor-pointer items-center justify-center border duration-100 hover:bg-base-100 focus:ring-2 focus:ring-gray-500 active:ring-2 active:ring-gray-500 text-white"
                  onClick={handleIncrease}
                >
                  +
                </button>
              </div>
              <br />
            </div>
            <div className="mt-7 flex flex-row items-center gap-6">
              <PayButton id={product.id} stock={product.metadata?.stock} metadata={{ count: quantity }} />
            </div>
          </div>
        </section>
      </div>
    </>
  );
}