import Products from "@/components/Products";
import { getAllProducts } from "@/lib/server";

export default async function page() {
  const products = await getAllProducts();
  return (
    <main>
      <main>
        <Products products={products} />
      </main>
    </main>
  );
}
