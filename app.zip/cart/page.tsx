"use client";
import { useEffect, useState } from 'react';
import Image from 'next/image';

interface CartProps {
    [productId: string]: {
        quantity: number;
    };
}

interface Product {
    id: string;
    image: string;
    title: string;
    price: number;
    description: string;
    metadata?: {
        stock?: number;
        new?: boolean;
        hidden?: boolean;
        category?: string;
    };
}

function Cart() {
    const [useCart, setCart] = useState<CartProps>({});
    const [useLoading, setLoading] = useState(true);
    const [useProducts, setProducts] = useState<Product[]>([]);

    async function createCheckout() {
        window.location.href = '/payment?productId=cart';
    }

    useEffect(() => {
        const fetchProduct = async () => {
            const response = await fetch("/api/products/");
            const data = await response.json();
            setProducts(data);
        };

        fetchProduct();
    }, []);

    useEffect(() => {
        const cartData = localStorage.getItem('cart');
        if (cartData) {
            const parsedCart: CartProps = JSON.parse(cartData);
            setCart(parsedCart);
        }

        setLoading(false);
    }, []);

    const clearCart = () => {
        setCart({});
        localStorage.removeItem('cart');
    };

    const removeItem = (id: string) => {
        const updatedCart = { ...useCart };
        delete updatedCart[id];
        setCart(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
    };

    const updateQuantity = (id: string, quantity: number) => {
        if (quantity <= 0) {
            removeItem(id);
        } else {
            const max_quantity = useProducts.find((product) => product.id === id)?.metadata?.stock ?? 0;
            if (quantity <= max_quantity) {
                const updatedCart = { ...useCart, [id]: { ...useCart[id], quantity } };
                setCart(updatedCart);
                localStorage.setItem('cart', JSON.stringify(updatedCart));
            } else {
                const updatedCart = { ...useCart, [id]: { ...useCart[id], max_quantity } };
                setCart(updatedCart);
                localStorage.setItem('cart', JSON.stringify(updatedCart));
            }
        }
    };

    if (useLoading) {
        return (
            <div className="px-2 mt-4 flex flex-col items-center justify-center lg:flex-row lg:items-start lg:gap-4 lg:flex-wrap min-h-screen">
                <div className="p-4 min-w-[80%] items-center justify-center">
                    <h1 className="text-2xl text-center">Loading...</h1>
                </div>
            </div>
        );
    }

    if (Object.keys(useCart).length === 0) {
        return (
            <div className="px-2 mt-4 flex flex-col items-center justify-center lg:flex-row lg:items-start lg:gap-4 lg:flex-wrap min-h-screen">
                <div role="alert" className="alert mx-8 mt-4">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        className="h-6 w-6 shrink-0 stroke-current">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Your cart is empty!</span>
                </div>
            </div>
        );
    }

    const totalPrice = Object.entries(useCart).reduce((total, [id, metadata]) => {
        const product = useProducts.find((product) => product.id === id);
        if (product) {
            return total + product.price * metadata.quantity;
        }
        return total;
    }, 0).toFixed(2);

    return (
        <div className="mt-4 mx-8">
            {Object.entries(useCart).map(([id, metadata]) => {
                const product = useProducts.find((product) => product.id === id);
                if (product) {
                    return (
                        <div key={id} className="flex items-center gap-4 p-2 border rounded-lg bg-white mt-2 relative">
                            <Image src={product.image} alt={product.title} width={200} height={200} />
                            <div>
                                <h1 className="text-xl font-semibold text-black">{product.title}</h1>
                                <p className="text-gray-600">{product.price}€</p>
                                <div className="flex">
                                    <button
                                        className="flex h-8 w-8 cursor-pointer items-center justify-center border duration-100 hover:bg-base-100 focus:ring-2 focus:ring-gray-500 active:ring-2 active:ring-gray-500 text-base-100 hover:text-white"
                                        onClick={() => updateQuantity(id, metadata.quantity - 1)}
                                    >
                                        -
                                    </button>
                                    <div className="flex h-8 w-8 cursor-text items-center justify-center border-t border-b active:ring-gray-500 text-gray-700">
                                        {metadata.quantity}
                                    </div>
                                    <button
                                        className="flex h-8 w-8 cursor-pointer items-center justify-center border duration-100 hover:bg-base-100 focus:ring-2 focus:ring-gray-500 active:ring-2 active:ring-gray-500 text-base-100 hover:text-white"
                                        onClick={() => updateQuantity(id, metadata.quantity + 1)}
                                    >
                                        +
                                    </button>
                                </div>
                            </div>
                            <button className="absolute top-2 right-2 p-2 text-white bg-red-500 rounded-full hover:bg-red-600" onClick={() => removeItem(id)}>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-6 w-6">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                    );
                }
            })}
            <button onClick={clearCart} className="btn btn-accent btn-outline bg-base-100">Clear</button>
            <div className="mt-4 flex items-center justify-between bg-base-100 p-2 rounded-xl">
                <h1 className="text-2xl font-semibold text-white ml-2">Total price: {Number(totalPrice).toFixed(2)}€</h1>
                <button onClick={createCheckout} className="px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600 min-w-[30%]">Checkout</button>
            </div>
        </div>
    );
}

export default Cart;
