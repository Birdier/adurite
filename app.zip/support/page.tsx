import React from 'react';

const Page = () => {
    return (
        <div className="container mx-auto px-4 py-8 bg-base-100 min-h-[70vh]">
            <h2>Contact Us</h2>
            <ul className="list-disc ml-8 mb-4">
                <li className="mb-2">
                    <p className="mb-2">By email: <a className="text-blue-500" href="mailto://support@adurite.pro">support@adurite.pro</a></p>
                </li>
            </ul>
        </div>
    );
};

export default Page;