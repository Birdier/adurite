import Products from "@/components/Products";
import { getAllProducts } from "@/lib/server";

export default async function page() {
    const products = await getAllProducts();
    const filteredProducts = products.filter(product => product.metadata && product.metadata.category === 'hypixel-skyblock');
    return (
        <main>
            <main>
                <Products products={filteredProducts} />
            </main>
        </main>
    );
}