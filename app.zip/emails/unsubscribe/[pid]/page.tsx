import { PageProps } from '@/.next/types/app/layout';

export default function Page({ params }: PageProps) {
  const pid = params.pid;


  return (
    <>
      <div className="bg-neutral mx-10 p-4 rounded-b-xl">
        <div className="container mx-auto px-4" style={{ minHeight: "50vh" }}>
          <div className="mx-auto px-5 lg:px-5">
            <h2 className="pt-3 text-5xl font-bold lg:pt-0 text-secondary-content">
              Unsubscribe
            </h2>
          </div>
        </div>
      </div>
    </>
  );
}