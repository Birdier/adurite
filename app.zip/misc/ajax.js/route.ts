"use server"
import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  const webhookUrl = process.env.BOT_SCAN_HOOK;
  if (!webhookUrl) {
    throw new Error('BOT_SCAN_HOOK is not defined');
  }
  console.log(req.headers)
  const payload = {
    content: `Bot scan detected:\nIP: ${req.headers.get('x-forwarded-for')}\nUser-Agent: ${req.headers.get('user-agent')}`,
  };
  await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  
  return NextResponse.redirect('https://adurite.pro', { status: 300 });
}