"use client";
import { useSearchParams } from "next/navigation";
import { loadStripe } from "@stripe/stripe-js";
import {
  EmbeddedCheckout,
  EmbeddedCheckoutProvider,
} from "@stripe/react-stripe-js";
import { createStripeCartCheckout, createStripeCheckout } from "@/lib/server";
import Link from "next/link";

const public_key = "pk_live_51PgTfKC5ldq6HhmVjhQYp1P9JjXZoFl6vaFcJYSFp0qPZS6PKN76lLvWPWSKkCr7HLg9NMHsvYTOOkyg2NHa7tYv00N6OETs7M";

function Page() {
  const searchParams = useSearchParams();
  const productId = searchParams.get("productId");
  const count = searchParams.get("count");
  if (!productId)
    return (
      <h1 className="text-5xl text-red-500 text-center">No Valid Product Id</h1>
    );

  async function fetchClientSecret(): Promise<string> {
    if (productId === "cart") {
      const cart = localStorage.getItem("cart");
      return await createStripeCartCheckout(JSON.parse(cart!));
    }    
    if (!count) {
      return await createStripeCheckout(productId!)
    } else {
      return await createStripeCheckout(productId!, parseInt(count!));
    }
  }

  const option = { fetchClientSecret };
  const stripe = loadStripe(public_key!);

  return (
    <main className="p-5">
      <div className="p-10 bg-[#172635] rounded-xl">
        {productId === "cart" ? (
          <Link href={`/cart`} className="btn btn-primary btn-outline text-primary text-2xl font-semibold mb-5">
            Back
          </Link>
        ) : (
          <Link href={`/products/${productId!}`} className="btn btn-primary btn-outline text-primary text-2xl font-semibold mb-5">
            Back
          </Link>
        )}
        <EmbeddedCheckoutProvider stripe={stripe} options={option}>
          <EmbeddedCheckout />
        </EmbeddedCheckoutProvider>
      </div>
    </main>
  );
}

export default Page;
